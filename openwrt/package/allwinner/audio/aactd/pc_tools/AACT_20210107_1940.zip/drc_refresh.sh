#!/bin/sh

REG_BASE_ADDR="0x01c22c00"

[ $# != 1 ] && {
    echo "usage:$0 file"
    exit
}

file=$1
reg_base=`printf %d $REG_BASE_ADDR`

while read line
do
    if [ x"${line:0:1}" = x"[" ]; then
    reg_offset=`echo $line |cut -d "=" -f 1 | cut -d "[" -f 2 | cut -d "]" -f 1`
    tmp_reg_offset=`printf %d $reg_offset`
    tmp_reg=`expr $tmp_reg_offset + $reg_base`
    reg=`printf 0x%x $tmp_reg`
    val=`echo $line |cut -d "=" -f 2`
    echo "reg:$reg=$val"
    echo $reg $val > /sys/class/sunxi_dump/write
    fi
done < $file

