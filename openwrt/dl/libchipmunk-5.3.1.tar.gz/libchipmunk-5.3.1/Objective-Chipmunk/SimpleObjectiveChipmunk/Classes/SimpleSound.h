@interface SimpleSound

+ (void)playSoundWithVolume:(float)volume;

@end