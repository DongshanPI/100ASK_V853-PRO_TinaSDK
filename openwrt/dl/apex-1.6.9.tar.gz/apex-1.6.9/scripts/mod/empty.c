/* empty file to figure out endianness / word size */
