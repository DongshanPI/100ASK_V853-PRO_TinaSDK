#define SLogTrace(...)
#define SLogError(...)
#define SLogWarning(...)
#define S_VAR_NOT_USED(x) do { (void)(x); } while (0)
