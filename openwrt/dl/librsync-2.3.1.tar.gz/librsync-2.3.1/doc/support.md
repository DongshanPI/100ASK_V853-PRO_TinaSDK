# Support {#page_support}

There are two mailing lists:

- https://groups.google.com/forum/#!forum/librsync-announce
- https://groups.google.com/forum/#!forum/librsync

There are some [questions and answers about librsync on stackoverflow.com tagged
`librsync`][stackoverflow].
That is a good place to see if your question has already been answered.

[stackoverflow]: http://stackoverflow.com/questions/tagged/librsync
