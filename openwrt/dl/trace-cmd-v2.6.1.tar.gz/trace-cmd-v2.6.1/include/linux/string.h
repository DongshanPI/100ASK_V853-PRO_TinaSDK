#ifndef __LINUX_STRING_H_
#define __LINUX_STRING_H_

char *str_error_r(int errnum, char *buf, size_t buflen);

#endif
