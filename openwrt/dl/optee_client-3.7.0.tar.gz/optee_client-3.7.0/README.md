# OP-TEE Client API
This git contains source code for the non-secure side implementation of the
OP-TEE project making up the client library and tee-supplicant.

All official OP-TEE documentation has moved to http://optee.readthedocs.io. The
information that used to be here in this git can be found under [optee_client].

// OP-TEE core maintainers

[optee_client]: https://optee.readthedocs.io/building/gits/optee_client.html
