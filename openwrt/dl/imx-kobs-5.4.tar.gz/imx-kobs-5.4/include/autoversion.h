/*  Copyright (C) 2013 Freescale Semiconductor, Inc. */
const char *git_sha = "unknown";
